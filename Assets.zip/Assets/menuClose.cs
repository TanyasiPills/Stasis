using UnityEngine;
using UnityEngine.EventSystems;

public class menuClose : MonoBehaviour
{
    Manager manager;

    private void Start()
    {
        manager = GameObject.FindGameObjectWithTag("manager").GetComponent<Manager>();
    }

}
