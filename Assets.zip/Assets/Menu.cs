using UnityEngine;
using UnityEngine.EventSystems;

public class Menu : MonoBehaviour, IPointerDownHandler
{
    Manager manager;

    void Start()
    {
        manager = GameObject.FindGameObjectWithTag("manager").GetComponent<Manager>();
    }

    public void OnPointerDown(PointerEventData eventData)
    {
        if (manager.UIIsOpen()) manager.UIChange();
    }
}
