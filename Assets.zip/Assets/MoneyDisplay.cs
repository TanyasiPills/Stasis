using TMPro;
using UnityEngine;

public class MoneyDisplay : MonoBehaviour
{
    Manager manager;
    TMP_Text text;

    private void Start()
    {
        manager = GameObject.FindGameObjectWithTag("manager").GetComponent<Manager>();
        text = gameObject.GetComponent<TMP_Text>();
    }

    void Update()
    {
        text.text = $"CC: {manager.cc}";
    }
}
